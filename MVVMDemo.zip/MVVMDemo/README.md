# MVVMDemo

Sample Project on latest android technologies and libraries listed below

#Kotlin
#ViewModel
#MVVM
#Retrofit
#RXJava
#Dagger2
#Recyclerview

#screenshots
![Screenshot_1594198742](https://user-images.githubusercontent.com/25319743/86899551-cc147700-c127-11ea-9439-f0c4d95af936.png)


